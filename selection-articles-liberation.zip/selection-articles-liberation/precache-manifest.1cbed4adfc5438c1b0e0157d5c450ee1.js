self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fe0428569e125879182a11bda781ab41",
    "url": "/apps/2020/03/selection-articles-liberation/index.html"
  },
  {
    "revision": "83ba8dd7e2893d41ae05",
    "url": "/apps/2020/03/selection-articles-liberation/static/js/2.e20b08fa.chunk.js"
  },
  {
    "revision": "fb5ccdac3c659746c5127592d1978b8a",
    "url": "/apps/2020/03/selection-articles-liberation/static/js/2.e20b08fa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5d2bc345fc7a8b79f7fa",
    "url": "/apps/2020/03/selection-articles-liberation/static/js/main.eba698fc.chunk.js"
  },
  {
    "revision": "644688d2b9c7c957d12c",
    "url": "/apps/2020/03/selection-articles-liberation/static/js/runtime-main.107634c2.js"
  },
  {
    "revision": "a425c13336867aea9ba169a48c65171e",
    "url": "/apps/2020/03/selection-articles-liberation/static/media/logo-glyph.a425c133.svg"
  }
]);